"""
generate_dataset.py
--------------------
Creates a labeled dataset of positive/negative text reviews for sentiment
analysis. Built offline (no downloads needed) by combining templates with
different subjects, opinions, and reasons -> gives a few thousand varied,
realistic-sounding sentences with 0 (negative) / 1 (positive) labels.

Run:
    python generate_dataset.py
Output:
    reviews.csv  (columns: review, sentiment)
"""

import csv
import random

random.seed(42)

subjects = [
    "the movie", "this film", "the product", "this app", "the restaurant",
    "the book", "this show", "the service", "the phone", "this game",
    "the hotel", "the laptop", "the album", "this course", "the delivery",
    "the customer support", "this headphone", "the update", "the recipe",
    "this gadget"
]

positive_openers = [
    "I absolutely loved {s}.",
    "{S} exceeded all my expectations.",
    "Honestly, {s} was fantastic.",
    "I can't stop recommending {s} to everyone.",
    "{S} was a pleasant surprise.",
    "What a wonderful experience with {s}.",
    "{S} worked perfectly and I'm impressed.",
    "I'm so happy with {s}.",
    "{S} is easily one of the best I've tried.",
    "Everything about {s} felt top notch.",
    "{S} made my day so much better.",
    "I would definitely buy/use {s} again.",
    "{S} was smooth, fast, and reliable.",
    "Kudos to the team behind {s}, it's excellent.",
    "{S} really impressed me with its quality.",
]

positive_reasons = [
    "The quality was outstanding.",
    "It was fast, easy, and reliable.",
    "The value for money was amazing.",
    "The design felt thoughtful and polished.",
    "Everyone was friendly and helpful.",
    "It exceeded what I paid for.",
    "The performance was smooth throughout.",
    "I'd give it a five star rating without hesitation.",
    "It solved my problem instantly.",
    "The attention to detail was great.",
    "",
]

negative_openers = [
    "I really did not like {s}.",
    "{S} was a huge disappointment.",
    "Honestly, {s} was terrible.",
    "I regret spending time on {s}.",
    "{S} did not meet my expectations at all.",
    "What a frustrating experience with {s}.",
    "{S} kept failing and it was annoying.",
    "I'm so unhappy with {s}.",
    "{S} is easily one of the worst I've tried.",
    "Everything about {s} felt cheap and rushed.",
    "{S} ruined my day.",
    "I would never recommend {s} to anyone.",
    "{S} was slow, buggy, and unreliable.",
    "Shame on the team behind {s}, it's awful.",
    "{S} really let me down with its quality.",
]

negative_reasons = [
    "The quality was awful.",
    "It was slow, confusing, and unreliable.",
    "It felt like a waste of money.",
    "The design felt lazy and unfinished.",
    "The staff were rude and unhelpful.",
    "It broke within a few days.",
    "The performance kept crashing.",
    "I'd give it a one star rating without hesitation.",
    "It never solved my problem.",
    "The attention to detail was missing.",
    "",
]

neutral_connectors = ["", " Overall,", " In the end,", " To sum up,", " Honestly,"]


def build_sentence(opener_tmpl, reason, subject):
    s_lower = subject
    s_cap = subject[0].upper() + subject[1:]
    sentence = opener_tmpl.format(s=s_lower, S=s_cap)
    connector = random.choice(neutral_connectors)
    if reason:
        sentence = f"{sentence}{connector} {reason}"
    return sentence.strip()


def generate(n_per_class=1000):
    rows = []
    for _ in range(n_per_class):
        subject = random.choice(subjects)
        opener = random.choice(positive_openers)
        reason = random.choice(positive_reasons)
        rows.append((build_sentence(opener, reason, subject), 1))

        subject = random.choice(subjects)
        opener = random.choice(negative_openers)
        reason = random.choice(negative_reasons)
        rows.append((build_sentence(opener, reason, subject), 0))

    random.shuffle(rows)
    return rows


def main():
    rows = generate(n_per_class=1000)
    # de-duplicate while keeping order
    seen = set()
    unique_rows = []
    for text, label in rows:
        if text not in seen:
            seen.add(text)
            unique_rows.append((text, label))

    with open("reviews.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["review", "sentiment"])
        writer.writerows(unique_rows)

    print(f"Saved {len(unique_rows)} unique labeled reviews to reviews.csv")


if __name__ == "__main__":
    main()
