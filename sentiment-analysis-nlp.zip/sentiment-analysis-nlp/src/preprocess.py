"""
preprocess.py
-------------
Simple, dependency-light text cleaning functions used before
turning text into numbers (TF-IDF) for the model.
"""

import re
import string


def clean_text(text: str) -> str:
    """
    Lowercases text, removes punctuation, numbers, and extra whitespace.
    Keeps it simple and fast -- no heavy NLP libraries required.
    """
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", " ", text)          # remove URLs
    text = re.sub(r"\d+", " ", text)                      # remove numbers
    text = text.translate(str.maketrans("", "", string.punctuation))  # remove punctuation
    text = re.sub(r"\s+", " ", text).strip()               # collapse whitespace
    return text
