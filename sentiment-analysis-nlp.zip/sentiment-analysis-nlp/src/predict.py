"""
predict.py
----------
Quick command-line tool to test the trained model.

Usage:
    python src/predict.py "This product was amazing, I loved it!"
"""

import os
import sys
import joblib

sys.path.append(os.path.dirname(__file__))
from preprocess import clean_text

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "model", "sentiment_model.pkl")
VECTORIZER_PATH = os.path.join(BASE_DIR, "model", "vectorizer.pkl")


def load_artifacts():
    model = joblib.load(MODEL_PATH)
    vectorizer = joblib.load(VECTORIZER_PATH)
    return model, vectorizer


def predict_sentiment(text, model=None, vectorizer=None):
    if model is None or vectorizer is None:
        model, vectorizer = load_artifacts()

    cleaned = clean_text(text)
    vec = vectorizer.transform([cleaned])
    pred = model.predict(vec)[0]
    proba = model.predict_proba(vec)[0]
    confidence = max(proba)

    label = "Positive 🙂" if pred == 1 else "Negative 🙁"
    return label, confidence


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print('Usage: python src/predict.py "your text here"')
        sys.exit(1)

    text = " ".join(sys.argv[1:])
    label, confidence = predict_sentiment(text)
    print(f"Text: {text}")
    print(f"Prediction: {label}  (confidence: {confidence:.2%})")
