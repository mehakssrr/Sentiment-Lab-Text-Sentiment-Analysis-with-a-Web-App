"""
app.py
------
A small Flask web app with a text box: type a review, click "Analyze",
and see whether the model thinks it's Positive or Negative.

Run from the project root:
    python app/app.py

Then open in your browser:
    http://127.0.0.1:5000
"""

import os
import sys

from flask import Flask, render_template, request

sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))
from predict import load_artifacts, predict_sentiment

app = Flask(__name__)

# Load the model once, when the server starts (fast predictions afterwards)
MODEL, VECTORIZER = None, None


def get_artifacts():
    global MODEL, VECTORIZER
    if MODEL is None or VECTORIZER is None:
        MODEL, VECTORIZER = load_artifacts()
    return MODEL, VECTORIZER


@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    confidence = None
    user_text = ""

    if request.method == "POST":
        user_text = request.form.get("review_text", "").strip()
        if user_text:
            model, vectorizer = get_artifacts()
            label, conf = predict_sentiment(user_text, model, vectorizer)
            result = label
            confidence = f"{conf:.2%}"

    return render_template(
        "index.html", result=result, confidence=confidence, user_text=user_text
    )


if __name__ == "__main__":
    # Load model at startup so the first request isn't slow
    get_artifacts()
    app.run(debug=True, host="0.0.0.0", port=5000)
